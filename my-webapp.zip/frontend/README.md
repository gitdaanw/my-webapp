# own-website
https://weerheim.eu

This repo is created for my school project for my HBO Software Engineering. 
In this module we need to create the frontend of a webapplication using only HTML, CSS and Javascript. 

The website is created with the goal to showcase my own pictures. There is a gallery for the pictures, a embedded Youtube video and the option to add a demo picture. 
Adding of other pictures is blocked to prevent legal issues when pictures other then my own are added. 
